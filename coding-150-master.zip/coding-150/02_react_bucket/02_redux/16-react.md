

1. 错误处理componentDidCatch(err,info)
2. 