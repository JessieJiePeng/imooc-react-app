//before
var name = 'imooc'
//after
let name = 'imooc'
const site = 'www.imooc.com'























