export name = 'imooc'
export age = 20
export function sayHello(){
    console.log(`hello ${name}`)
}

export default site='imooc.com'