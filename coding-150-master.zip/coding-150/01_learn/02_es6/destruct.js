
const [name, age] = ['imooc', '20']
const {title,job} = {title:'React开发App', job:'IT'}

console.log(name,age)
console.log(title,job)