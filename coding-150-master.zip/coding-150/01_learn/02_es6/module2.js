import site, {name, age} from './module1'
import * as module1 from './module1'
console.log(site,name,age)
moule1.sayHello()