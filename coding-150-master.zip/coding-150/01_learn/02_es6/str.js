
let name='imooc'
// before
console.log('hello '+name+'! \n thank you!')
// after
console.log(`hello ${name}!
  thankyou`)
