# react-chat
react16+redux+express+mongodb构建聊天app

#mushroom

慕课React-redux课程源码



## 慕课网课程，涉及的技术

* React16
* redux 管理状态
* react-router4 路由
* antd-mobile 蚂蚁金服UI组件库
* express 
* mongodb
* socket.io

希望录制一个高质量的课程
